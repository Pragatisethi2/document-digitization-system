| Metric             |   Receipts |   Forms | Better Dataset   | Difference %   |
|:-------------------|-----------:|--------:|:-----------------|:---------------|
| ROUGE-1            |     0.189  |  0.4698 | Forms            | 59.76%         |
| ROUGE-2            |     0.0989 |  0.3696 | Forms            | 73.24%         |
| ROUGE-L            |     0.1827 |  0.4698 | Forms            | 61.12%         |
| Inference Time (s) |     0.9    |  2.21   | Receipts         | 59.12%         |