| Metric             |   Receipts |   Forms | Better Dataset   | Difference %   |
|:-------------------|-----------:|--------:|:-----------------|:---------------|
| ROUGE-1            |     0.5951 |  0.7634 | Forms            | 22.05%         |
| ROUGE-2            |     0.4614 |  0.7269 | Forms            | 36.53%         |
| ROUGE-L            |     0.5407 |  0.7634 | Forms            | 29.18%         |
| Inference Time (s) |    38.67   | 46.49   | Receipts         | 16.82%         |