| Metric             |   Receipts |   Forms | Better Dataset   | Difference %   |
|:-------------------|-----------:|--------:|:-----------------|:---------------|
| ROUGE-1            |     0.4054 |  0.6962 | Forms            | 41.76%         |
| ROUGE-2            |     0.214  |  0.533  | Forms            | 59.84%         |
| ROUGE-L            |     0.3079 |  0.6471 | Forms            | 52.41%         |
| Inference Time (s) |    14.15   | 33.83   | Receipts         | 58.16%         |